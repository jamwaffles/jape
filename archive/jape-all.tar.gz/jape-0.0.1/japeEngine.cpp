typedef struct
{
	float posx, posy, posz;
	float velx, vely, velz;
	float accx, accy, accz;
	float colr, colg, colb;
	
	float life;
	float fade;
}
japeParticle;
