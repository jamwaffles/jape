class openglTerminal
{
	public:
		
		void print(char text[100]);
		void showLines(void);
};
